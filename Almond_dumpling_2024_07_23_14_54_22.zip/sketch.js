function setup() {
  createCanvas(600,600);
  background("white");
}

function draw() {
 
   stroke("black");
  fill("purple");
  
   // console.log (mouseIsPressed);
  
  if (mouseIsPressed) {
    circle(mouseX,mouseY,30,45);  
  } 
}